%Calculate the  sensitivity distribution with  reiceiver at (4000, 0, 999.9) m for inline system of marine CSEM  at plan view and section view

%input:
%bc,h,z                -layered model description
%TX,T0,f,              -parameters of dipole source  
%RC                    -position of the receiver 
%xxP,yyP,zzP           -position of the elements at plan view
%xxD,yyD,zzD           -position of the elements at section view

%output:
%XEx,XEy,XEz     -the electric field at measurement points by x-directed magnetic dipole source
%AEX             -the electric field at the receiver by the vector electric dipole source within the elements

%code structure:
%call: slect_model   -to rearrange the layered model parameters according to the position of the dipole source
%call: E_XED         -to return the electric fields at the discrete element
%call: CAL_AEX       -to calculate the x-directed electric field  at the receiver caused by vector electric dipole source in the elements

tic;
%PLAN VIEW
%position of the elements in plan view
bc=[1d-12,   3.3                1];%conducutivity from the topmost layer to bottom layer
h=[1d60,    1000             1d60];%thickness from the topmost layer to bottom layer
z=[      0       1000            ];%z-coordinate of the layer's interface
%design the Tx-Rx
TX=[0,0,950];                      %position of the transmitter
T0=2;                              % the source layer is the 2th layer 
[Tmodel0,TmodelM,TmodelN]=select_model(T0,bc,h,z);% Rearrange the order of layers
f=1;                               %frequency of the transmitter
%center points of discrete volume 
xxP=-4200:400:8200;
yyP=200:400:3000;
zzP=1100;
P=length(xxP)*length(yyP)*length(zzP);
PS=zeros(P,3);
for i=1:length(xxP)
  for j=1:length(yyP)
      for k=1:length(zzP)
        m=(i-1)*length(yyP)*length(zzP)+(j-1)*length(zzP)+k;
        PS(m,1)=xxP(i);
        PS(m,2)=yyP(j);
        PS(m,3)=zzP(k);
      end
  end
end

 [ XEx,XEy,XEz ]=E_XED(PS,TX,Tmodel0,TmodelM,TmodelN,f);%return the electric fields by x-directed electric source 
 
 %formulate the sensitivity
 POS=ones(P,8);
 POS(:,1:3)=PS(:,1:3);
 S0=3; %the discrete cells located at the 3th layer                                       
[model0,modelM,modelN]=select_model(S0,bc,h,z);
RC=[4000,0,999.9];%position of the receriver for sensitivity test
AEX=CAL_AEX(RC,POS(:,1:8),model0,modelM,modelN,f); %return the x-directed electric fields by unit vector electric dipole

SEX=zeros(P,1);
for i=1:P
    SEX(i)=AEX(1,(i-1)*3+1)*XEx(i)+AEX(1,(i-1)*3+2)*XEy(i)+AEX(1,(i-1)*3+3)*XEz(i);%acumulate the x-directed electric fields by vector electric fields at discrete cells with unit volume
end
[PXEx,PXEy,PXEz]=E_XED(RC,TX,Tmodel0,TmodelM,TmodelN,f);  %return the electric fields by unit x-directed electric dipole
SEX_AMP=1+(abs(PXEx-0.99*3.2*1d7*SEX)-abs(PXEx))/abs(PXEx);  %3.2*1d7 is the volume of the uniform discrete cells, 0.99 is 
SEX_PHASE=180/pi*(phase(PXEx-0.99*3.2*1d7*SEX)-phase(PXEx));

%output results
filename1=strcat(num2str(f),'Hz','marine sensitivity plane view.txt');
fid1=fopen(filename1,'wt');
for i=1:P
    fprintf(fid1,'%12.7g\t',PS(i,1));%the x-coordinate of the discrete volume
    fprintf(fid1,'%12.7g\t',PS(i,2));%the y-coordinate of the discrete volume
    fprintf(fid1,'%12.7g\t',SEX_AMP(i));%the amplitude attenuation ratio caused by the conductivity abnormal discrete volume
    fprintf(fid1,'%12.7g\n',SEX_PHASE(i));%the phase difference caused by the conductivity abnormal discrete volume  
end


%%

%%SECTION VIEW
%position of the elements in section view
xxD=-4200:400:8200;
yyD=0;
zzD=1100.1:200:4100.1;
P=length(xxD)*length(yyD)*length(zzD);
PS=zeros(P,3);
for i=1:length(xxD)
  for j=1:length(yyD)
      for k=1:length(zzD)
        m=(i-1)*length(yyD)*length(zzD)+(j-1)*length(zzD)+k;
        PS(m,1)=xxD(i);
        PS(m,2)=yyD(j);
        PS(m,3)=zzD(k);
      end
  end
end

 [ XEx,XEy,XEz ]=E_XED(PS,TX,Tmodel0,TmodelM,TmodelN,f);
 
 POS=ones(P,8);
 POS(:,1:3)=PS(:,1:3);
 S0=3;                                         
[model0,modelM,modelN]=select_model(S0,bc,h,z);
RC=[4000,0,999.9];
AEX=CAL_AEX(RC,POS(:,1:8),model0,modelM,modelN,f); 

SEX=zeros(P,1);

for i=1:P
    SEX(i)=AEX(1,(i-1)*3+1)*XEx(i)+AEX(1,(i-1)*3+2)*XEy(i)+AEX(1,(i-1)*3+3)*XEz(i);

end
[PXEx,PXEy,PXEz]=E_XED(RC,TX,Tmodel0,TmodelM,TmodelN,f);
SEX_AMP=1+(abs(PXEx-0.99*3.2*1d7*SEX)-abs(PXEx))/abs(PXEx);
SEX_PHASE=180/pi*(phase(PXEx-0.99*3.2*1d7*SEX)-phase(PXEx));

%output results
filename2=strcat(num2str(f),'Hz','marine sensitivity section view.txt');
fid2=fopen(filename2,'wt');
for i=1:P
    fprintf(fid2,'%12.7g\t',PS(i,1));%the x-coordinate of the discrete volume
    fprintf(fid2,'%12.7g\t',PS(i,3));%the z-coordinate of the discrete volume
    fprintf(fid2,'%12.7g\t',SEX_AMP(i));%the amplitude attenuation ratio caused by the conductivity abnormal discrete volume
    fprintf(fid2,'%12.7g\n',SEX_PHASE(i));%the phase difference caused by the conductivity abnormal discrete volume  
end
toc;





