%Calculate the  electric field distribution for z-directed magnetic dipole source
%at plan view and section view

%input:
%bc,h,z                -layered model description
%TX,T0,f,              -parameters of dipole source  
%xxP,yyP,zzP           -position of the measurement points at plan view
%xxD,yyD,zzD           -position of the measurement points at section view

%output:
%XEx,XEy,XEz     -the electric field at measurement points by z-directed magnetic dipole source

%code structure:
%call: slect_model   -to rearrange the layered model parameters according to the position of the dipole source
%call: E_ZMD         -to return the electric fields by z-directed magnethic dipole

%PLAN VIEW
%layered model description 
bc=[1d-12,                  0.01];%conductivity of each layers(from topmost to bottom layer);
h=[1d60,                 1d60];%thickness of each layer
z=[             0            ];%interface
%dipole source description  
TX=[0,0,-30];                %position of the dipole source
T0=1;                        % the transmitter is in the top layer 
[Tmodel0,TmodelM,TmodelN]=select_model(T0,bc,h,z);% Rearrange the order of layers 
f=10000;                      %frequency of the transmitter
%positions of the measurement points
xxP=-200:16:200;
yyP=-200:16:200;
zzP=20;
P=length(xxP)*length(yyP)*length(zzP);
PS=zeros(P,3);                  
for i=1:length(xxP)
  for j=1:length(yyP)
      for k=1:length(zzP)
        m=(i-1)*length(yyP)*length(zzP)+(j-1)*length(zzP)+k;
        PS(m,1)=xxP(i);
        PS(m,2)=yyP(j);
        PS(m,3)=zzP(k);
      end
  end
end

[ XEx,XEy,XEz ]=E_ZMD(PS,TX,Tmodel0,TmodelM,TmodelN,f);%return the electric fields by z-directed magnethic dipole
%output the results for figures          
filename1=strcat(num2str(f),'Hz','airborne ZMD caused eleltric vectors plane view.txt');% the output file
fid1=fopen(filename1,'wt');
for i=1:P
    fprintf(fid1,'%12.5g\t',PS(i,1));
    fprintf(fid1,'%12.5g\t',PS(i,2));  
    fprintf(fid1,'%12.5g\t',real(XEx(i)));
    fprintf(fid1,'%12.5g\t',imag(XEx(i)));
    fprintf(fid1,'%12.5g\t',real(XEy(i)));
    fprintf(fid1,'%12.5g\n',imag(XEy(i)));
end

ExP_inphase=zeros(length(yyP),length(xxP));
ExP_outphase=zeros(length(yyP),length(xxP));
EyP_inphase=zeros(length(yyP),length(xxP));
EyP_outphase=zeros(length(yyP),length(xxP));
ESP_inphase=zeros(length(yyP),length(xxP));
ESP_outphase=zeros(length(yyP),length(xxP));

for i=1:length(xxP)
for j=1:length(yyP)   
    
    k=(i-1)*length(yyP)+j; 
    
    ExP_inphase(j,i)=real(XEx(k));  
    ExP_outphase(j,i)=imag(XEx(k));
    EyP_inphase(j,i)=real(XEy(k));  
    EyP_outphase(j,i)=imag(XEy(k));
    ESP_inphase(j,i)=log10(0.01*(sqrt(real(XEx(k))^2+real(XEy(k))^2)));  
    ESP_outphase(j,i)=log10(0.01*(sqrt(imag(XEx(k))^2+imag(XEy(k))^2)));       
end
end

%%SECTION VIEW
%layered model description
bc=[1d-12,                  0.01];
h=[1d60,                 1d60];
z=[             0            ];
%dipole source description
TX=[0,0,-30];
T0=1;
[Tmodel0,TmodelM,TmodelN]=select_model(T0,bc,h,z);
f=10000;
%position of the measurement points
xxD=-202:4:202;
yyD=0;
zzD=0:2:100;
P=length(xxD)*length(yyD)*length(zzD);
PS=zeros(P,3);
for i=1:length(xxD)
  for j=1:length(yyD)
      for k=1:length(zzD)
        m=(i-1)*length(yyD)*length(zzD)+(j-1)*length(zzD)+k;
        PS(m,1)=xxD(i);
        PS(m,2)=yyD(j);
        PS(m,3)=zzD(k);
      end
  end
end

[ XEx,XEy,XEz ]=E_ZMD(PS,TX,Tmodel0,TmodelM,TmodelN,f);
 %output the results for figures        
filename2=strcat(num2str(f),'Hz','airborne ZMD caused eleltric vectors section view.txt');
fid2=fopen(filename2,'wt');
for i=1:P
    fprintf(fid2,'%12.5g\t',PS(i,1));
    fprintf(fid2,'%12.5g\t',PS(i,3));  
    fprintf(fid2,'%12.5g\t',real(XEx(i)));
    fprintf(fid2,'%12.5g\t',imag(XEx(i)));
    fprintf(fid2,'%12.5g\t',real(XEy(i)));
    fprintf(fid2,'%12.5g\n',imag(XEy(i)));
end

ExD_inphase=zeros(length(zzD),length(xxD));
ExD_outphase=zeros(length(zzD),length(xxD));
EyD_inphase=zeros(length(zzD),length(xxD));
EyD_outphase=zeros(length(zzD),length(xxD));
ESD_inphase=zeros(length(zzD),length(xxD));
ESD_outphase=zeros(length(zzD),length(xxD));

for i=1:length(xxD)
for j=1:length(zzD)  
    
    k=(i-1)*length(zzD)+j; 
    
    ExD_inphase(j,i)=real(XEx(k));  
    ExD_outphase(j,i)=imag(XEx(k));
    EyD_inphase(j,i)=real(XEy(k));  
    EyD_outphase(j,i)=imag(XEy(k));
    ESD_inphase(j,i)=log10(0.01*(sqrt(real(XEx(k))^2+real(XEy(k))^2)));  
    ESD_outphase(j,i)=log10(0.01*(sqrt(imag(XEx(k))^2+imag(XEy(k))^2)));       
end
end



