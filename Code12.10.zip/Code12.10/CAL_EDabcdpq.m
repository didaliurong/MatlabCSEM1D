%For both horizontal and vertical electric dipoles,return the coefficents of vector potentials in each layer.

%With measure point in the source layer but beneath the source:C0MM=[A0M,B0M,C0M,D0M,P0M,Q0M,u0,v0,gama0,bc0,w] 
%A0M,B0M,C0M,D0M are a, b, c,d coefficents in equation (5) and
%(6)for horizontal electric dipole.
%P0M and Q0M are coefficents of W_i in equation (14) for vertical electric dipole, 
%which are represented by c and d in eqaution (6), respectively.
%u0,v0,gama0,bc0,w are source layer paramters.

%With measure point in the source layer but above the source:C0NN=[A0N,B0N,C0N,D0N,P0N,Q0N,u0,v0,gama0,bc0,w];
%A0N,B0N,C0N,D0N are a, b, c,d coefficents in equation (5) and
%(6)for horizontal electric dipole.
%P0N,Q0N are coefficents of W_i in equation (14) for vertical electric dipole, 
%which are represented by c and d in eqaution (6), respectively.
%u0,v0,gama0,bc0,w are source layer paramters.

%With measure point in the layer beneath the source layer:CMM(m,1:11)=[AM(m),BM(m),CM(m),DM(m),PM(m),QM(m),uM(m),vM(m),gamaM(m),bcM(m),w];
%m indicates the measurement point in the m^(th) lower layer, AM,BM,CM,DM are a, b, c,d coefficents in equation (5) and
%(6)for horizontal electric dipole.
%PM and QM are coefficents of W_i in equation (14) for vertical electric dipole, 
%which are represented by c and d in eqaution (6), respectively.
%uM,vM,gamaM,bcM,w are the m^(th) layer's paramters.

%With measure point in the layer above the source layer:CNN(n,1:11)=[AN(n),BN(n),CN(n),DN(n),PN(n),QN(n),uN(n),vN(n),gamaN(n),bcN(n),w];
%n indicates the measurement point in the n^(th) lower layer, AN,BN,CN,DN are a, b, c,d coefficents in equation (5) and
%(6)for horizontal electric dipole.
%PN and QN are coefficents of W_i in equation (14) for vertical electric dipole, 
%which are represented by c and d in eqaution (6), respectively.
%uN,vN,gamaN,bcN,w are the n^(th) layer's paramters.
function [C0MM,C0NN,CMM,CNN] = CAL_EDabcdpq(L,model0,modelM,modelN,zR,zT,w)
J=sqrt(-1);
mu=4*pi*1e-7;
zR=zR-zT;%using the relative Z coordinate between the source and measurement point
%!!!digits(50); % using digits more than 32 for high accuracy,if neccesary
%model0 parameters
bc0=model0(1,1);
h0=model0(1,2);
uu0=(L^2+J*w*mu*bc0);
u0=(sqrt(uu0));        %equation (6)
v0=(1/u0);             %equation (9)
gama0=(J*w*mu*bc0/u0); %explanation of equation (13)

%for the source located at the middle layer
if length(modelM)~=1   %if there exist upper layers return the parameters prepared for coeffcients
    [M,bcM,zM,uM,vM,gamaM,TM,YM,RM,XM]=make_M(L,w,zT,modelM,v0,gama0);
end
if length(modelN)~=1   %if there exist lower layers return the parameters prepared for coeffcients
    [N,bcN,zN,uN,vN,gamaN,TN,YN,RN,XN]=make_N(L,w,zT,modelN,v0,gama0);
end

%for the source located at the topmost or bottom layer
if length(modelM)==1   %if the source in the bottom layer, calculate the coefficents for source layer and upper layers
    [C0MM,C0NN,CMM,CNN]=makeED_M0(L,zR,model0,w,N,bcN,zN,uN,vN,gamaN,TN,YN,RN,XN); 
end
if length(modelN)==1   %if the source in the topmost layer, calculate the coefficents for source layer and lower layers
    [C0MM,C0NN,CMM,CNN]=makeED_N0(L,zR,model0,w,M,bcM,zM,uM,vM,gamaM,TM,YM,RM,XM); 
end

%for the source located at middle layer, calculate the coefficents of the vector potentials 
if length(modelM)~=1&&length(modelN)~=1
%coefficents in the layers beneath the source layer
    AM=zeros(M,1);
    BM=zeros(M,1);
    CM=zeros(M,1);
    DM=zeros(M,1);
    PM=zeros(M,1);
    QM=zeros(M,1);
%coefficents in the source layer but beneath the source  
    A0M=(exp(u0*zR-2*u0*zM(1))+RN*exp(u0*zR-2*u0*h0))/(RM-RN*exp(-2*u0*h0)); %according to equation (8b)and (3b)
    B0M=RM*(RN*exp(2*u0*zN(1)-u0*zR)+exp(-u0*zR))/(RM-RN*exp(-2*u0*h0));     %according to equation (8b)and (3b)
%Comparing with equation (8b)and (3b) AOM and BOM, the exponential term exp(u0*zR) in equation (6) added and lamda/u0 removed.
%And we have corresponding works in the inline function EyKernels = getCSEM1DKernelsVX called by functions: E_qweXED, E_qweXMD,E_qweZED, E_qweZMD
%to recover this.The purpose is to avoid unstability problem by the
%exponential term.
    C0M=(XN*exp(u0*zR-2*u0*h0)-exp(u0*zR-2*u0*zM(1)))/(XM-XN*exp(-2*u0*h0)); %according to equation (4c)and (3c)
    D0M=(XM)*(XN*exp(2*u0*zN(1)-u0*zR)-exp(-u0*zR))/(XM-XN*exp(-2*u0*h0));   %according to equation (4c)and (3c)
%Comparing with equation (4c) and (3c)COM and DOM, the exponential term exp(u0*zR) in equation (6) added and 1/lamda removed.
%And we have corresponding works in the inline function EyKernels = getCSEM1DKernelsVX called by functions: E_qweXED, E_qweXMD,E_qweZED, E_qweZMD
%to recover this.The purpose is to avoid unstability problem by the exponential
%term.
    P0M=(exp(u0*zR-2*u0*zM(1))+XN*exp(u0*zR-2*u0*h0))/(XM-XN*exp(-2*u0*h0)); %explanation of equation (16)and explanation of equation (13), which is similar to AOM
    Q0M=XM*(XN*exp(2*u0*zN(1)-u0*zR)+exp(-u0*zR))/(XM-XN*exp(-2*u0*h0));     %explanation of equation (16)and explanation of equation (13), which is similar to BOM
%the exponential term exp(u0*zR) in equation (6) added and lamda/u0 removed.
%And we have corresponding works the inline function EyKernels = getCSEM1DKernelsVX called by functions: E_qweXED, E_qweXMD,E_qweZED, E_qweZMD
%recover this.The purpose is to avoid unstability problem by the
%exponential term.
    
    UA=(TM(1)-vM(1))/(TM(1)-v0);
    UB=(TM(1)+vM(1))/(TM(1)+v0);
    UC=(YM(1)-gamaM(1))/(YM(1)-gama0);
    UD=(YM(1)+gamaM(1))/(YM(1)+gama0);
 %calculate coefficents in the layers beneath the source layer   
    AXP=uM(1)*zR+zM(1)*(u0-uM(1)); %where the positive exponential term: uM(1)*zR in equation (6) have added
    AM(1)=UA*(exp(AXP-2*u0*zM(1))+RN*exp(AXP-2*u0*h0))/(RM-RN*exp(-2*u0*h0)); %according to equation (10),with AOM explicitly expressed.
 
    CM(1)=UC*(XN*exp(AXP-2*u0*h0)-exp(AXP-2*u0*zM(1)))/(XM-XN*exp(-2*u0*h0)); %explanation of equation (13),similar to equation (10),with COM explicitly expressed. 
    PM(1)=UC*(exp(AXP-2*u0*zM(1))+XN*exp(AXP-2*u0*h0))/(XM-XN*exp(-2*u0*h0)); %explanation of equation (16)and (13),similar to equation (10)
    
    BXP=-uM(1)*zR+zM(1)*(uM(1)-u0);%where the negative exponential term: uM(1)*zR in equation (6) have added
    BM(1)=UB*(RM*RN*exp(2*u0*zN(1)+BXP)+exp(BXP)*RM)/(RM-RN*exp(-2*u0*h0)); %according to equation (10),with BOM explicitly expressed.
    DM(1)=UD*(XM)*(XN*exp(2*u0*zN(1)+BXP)-exp(BXP))/(XM-XN*exp(-2*u0*h0));  %explanation of equation (13),similar to equation (10),with DOM explicitly expressed. 
    QM(1)=UD*(XM*XN*exp(2*u0*zN(1)+BXP)+exp(BXP)*XM)/(XM-XN*exp(-2*u0*h0)); %explanation of equation (16)and (13),similar to equation (10)
    
    if M>1
        AXP=zM(1)*(u0-uM(1));
        BXP=zM(1)*(uM(1)-u0);
        for i=2:M
            UA=UA*(TM(i)-vM(i))/(TM(i)-vM(i-1));
            AXP=AXP+zM(i)*(uM(i-1)-uM(i));
            AM(i)=(exp(uM(i)*zR+AXP-2*u0*zM(1))+RN*exp(uM(i)*zR+AXP-2*u0*h0))/(RM-RN*exp(-2*u0*h0))*UA;%according to equation (10)
            %where the positive exponential term: uM(i)*zR in equation
            %(6) have added
            UB=UB*(TM(i)+vM(i))/(TM(i)+vM(i-1));
            BXP=BXP+zM(i)*(uM(i)-uM(i-1));
            BM(i)=(RM*RN*exp(2*u0*zN(1)+BXP-uM(i)*zR)+exp(BXP-uM(i)*zR)*RM)/(RM-RN*exp(-2*u0*h0))*UB;%according to equation (10)
            %where the negative exponential term: -uM(i)*zR in equation
            %(6) have added
            UC=UC*(YM(i)-gamaM(i))/(YM(i)-gamaM(i-1));          
            CM(i)=(XN*exp(uM(i)*zR+AXP-2*u0*h0)-exp(uM(i)*zR+AXP-2*u0*zM(1)))/(XM-XN*exp(-2*u0*h0))*UC; %explanation of equation (13),similar to equation (10) 
            %where the positive exponential term: uM(i)*zR in equation
            %(6) have added
            UD=UD*(YM(i)+gamaM(i))/(YM(i)+gamaM(i-1));
            DM(i)=(XM)*(XN*exp(2*u0*zN(1)+BXP-uM(i)*zR)-exp(BXP-uM(i)*zR))/(XM-XN*exp(-2*u0*h0))*UD; %explanation of equation (13),similar to equation (10)
            %where the negative exponential term: -uM(i)*zR in equation
            %(6) have added
            PM(i)=(exp(AXP-2*u0*zM(1)+uM(i)*zR)+XN*exp(AXP-2*u0*h0+uM(i)*zR))/(XM-XN*exp(-2*u0*h0))*UC;%explanation of equation (16)and (13),similar to equation (10)
            %where the positive exponential term: uM(i)*zR in equation
            %(6) have added
            QM(i)=(XM*XN*exp(2*u0*zN(1)+BXP-uM(i)*zR)+exp(BXP-uM(i)*zR)*XM)/(XM-XN*exp(-2*u0*h0))*UD;  %explanation of equation (16)and (13),similar to equation (10)
            %where the negative exponential term: -uM(i)*zR in equation
            %(6) have added
        end
    end
    
%coefficents in the layers above the source layer
    AN=zeros(N,1);
    BN=zeros(N,1);
    CN=zeros(N,1);
    DN=zeros(N,1);
    PN=zeros(N,1);
    QN=zeros(N,1);
   %coefficents in the source layer but above the source  
    A0N=(exp(u0*zR-2*u0*zM(1))+exp(u0*zR)*RM)/(RM-RN*exp(-2*u0*h0)); %according to equation (8b) and (6b)
    B0N=RN*(exp(-2*u0*h0-u0*zR)+RM*exp(2*u0*zN(1)-u0*zR))/(RM-RN*exp(-2*u0*h0));%according to equation (8b) and (6b)
%Comparing with equation (8b)and (6b)AON and BON, the exponential term exp(u0*zR) in equation (6) added and lamda/u0 removed.
%And we have corresponding works in the inline function EyKernels = getCSEM1DKernelsVX called by functions: E_qweXED, E_qweXMD,E_qweZED, E_qweZMD
%to recover this.The purpose is to avoid unstability problem by the
%exponential term.
    C0N=(exp(u0*zR)*XM-exp(u0*zR-2*u0*zM(1)))/(XM-XN*exp(-2*u0*h0));%according to equation (4c)and (3c)
    D0N=XN*(XM*exp(2*u0*zN(1)-u0*zR)-exp(-2*u0*h0-u0*zR))/(XM-XN*exp(-2*u0*h0));%according to equation (4c)and (3c)
%Comparing with equation (4c) and (3c)CON and DON, the exponential term exp(u0*zR) in equation (6) added and 1/lamda removed.
%And we have corresponding works in the inline function EyKernels = getCSEM1DKernelsVX called by functions: E_qweXED, E_qweXMD,E_qweZED, E_qweZMD
%to recover this.The purpose is to avoid unstability problem by the exponential
%term.    
    P0N=(exp(u0*zR-2*u0*zM(1))+exp(u0*zR)*XM)/(XM-XN*exp(-2*u0*h0));%explanation of equation (16)and (13), which is similar to AON
    Q0N=XN*(exp(-2*u0*h0-u0*zR)+XM*exp(2*u0*zN(1)-u0*zR))/(XM-XN*exp(-2*u0*h0));%explanation of equation (16)and (13), which is similar to BON
%the exponential term exp(u0*zR) in equation (6) added and lamda/u0 removed.
%And we have corresponding works in the inline function EyKernels = getCSEM1DKernelsVX called by functions: E_qweXED, E_qweXMD,E_qweZED, E_qweZMD
%recover this.The purpose is to avoid unstability problem by the
%exponential term.    

    UA=(TN(1)-vN(1))/(TN(1)-v0);
    UB=(TN(1)+vN(1))/(TN(1)+v0);
    UC=(YN(1)-gamaN(1))/(YN(1)-gama0);
    UD=(YN(1)+gamaN(1))/(YN(1)+gama0);
%calculate coefficents in the layers above the source layer    
    AXP=uN(1)*zR+zN(1)*(u0-uN(1));%where the positive exponential term: uN(1)*zR in equation (6) have added
    AN(1)=(exp(AXP-2*u0*zM(1))+exp(AXP)*RM)/(RM-RN*exp(-2*u0*h0))*UA;%according to equation (11),with AON explicitly expressed.
    CN(1)=(exp(AXP)*XM-exp(AXP-2*u0*zM(1)))/(XM-XN*exp(-2*u0*h0))*UC; %explanation of equation (13),similar to equation (11),with CON explicitly expressed. 
    PN(1)=(exp(AXP-2*u0*zM(1))+exp(AXP)*XM)/(XM-XN*exp(-2*u0*h0))*UC;%explanation of equation (16)and (13),similar to equation (11)
    
    BXP=-uN(1)*zR+zN(1)*(uN(1)-u0);%where the negative exponential term: -uN(1)*zR in equation (6) have added
    BN(1)=RN*(exp(BXP-2*u0*h0)+RM*exp(BXP+2*u0*zN(1)))/(RM-RN*exp(-2*u0*h0))*UB;  %according to equation (11),with BON explicitly expressed.
    DN(1)=XN*(XM*exp(2*u0*zN(1)+BXP)-exp(BXP-2*u0*h0))/(XM-XN*exp(-2*u0*h0))*UD;  %according to equation (11),with DON explicitly expressed.
    QN(1)=XN*(exp(BXP-2*u0*h0)+XM*exp(2*u0*zN(1)+BXP))/(XM-XN*exp(-2*u0*h0))*UD; %explanation of equation (16)and (13),similar to equation (11)
    
    if N>1
        AXP=zN(1)*(u0-uN(1));
        BXP=zN(1)*(uN(1)-u0);
        
        for j=2:N
            UA=UA*(TN(j)-vN(j))/(TN(j)-vN(j-1));
            AXP=AXP+zN(j)*(uN(j-1)-uN(j));
            AN(j)=(exp(AXP-2*u0*zM(1)+uN(j)*zR)+exp(AXP+uN(j)*zR)*RM)/(RM-RN*exp(-2*u0*h0))*UA;%according to equation (11)
            %where the positive exponential term: uN(j)*zR in equation
            %(6) have added
            UB=UB*(TN(j)+vN(j))/(TN(j)+vN(j-1));
            BXP=BXP+zN(j)*(uN(j)-uN(j-1));
            BN(j)=RN*(exp(BXP-2*u0*h0-uN(j)*zR)+RM*exp(BXP+2*u0*zN(1)-uN(j)*zR))/(RM-RN*exp(-2*u0*h0))*UB;%according to equation (11)
            %where the negative exponential term: -uN(j)*zR in equation
            %(6) have added
            UC=UC*(YN(j)-gamaN(j))/(YN(j)-gamaN(j-1));
            CN(j)=(exp(AXP+uN(j)*zR)*XM-exp(AXP-2*u0*zM(1)+uN(j)*zR))/(XM-XN*exp(-2*u0*h0))*UC; %explanation of equation (13),similar to equation (11) 
            %where the positive exponential term: uN(j)*zR in equation
            %(6) have added
            UD=UD*(YN(j)+gamaN(j))/(YN(j)+gamaN(j-1));
            DN(j)=XN*(XM*exp(2*u0*zN(1)+BXP-uN(j)*zR)-exp(BXP-2*u0*h0-uN(j)*zR))/(XM-XN*exp(-2*u0*h0))*UD;%explanation of equation (13),similar to equation (11) 
            %where the negative exponential term: -uN(j)*zR in equation
            %(6) have added
            PN(j)=(exp(AXP-2*u0*zM(1)+uN(j)*zR)+exp(AXP+uN(j)*zR)*XM)/(XM-XN*exp(-2*u0*h0))*UC;%explanation of equation (16)and (13),similar to equation (11)
            %where the positive exponential term: uN(j)*zR in equation
            %(6) have added
            QN(j)=XN*(exp(BXP-2*u0*h0-uN(j)*zR)+XM*exp(2*u0*zN(1)+BXP-uN(j)*zR))/(XM-XN*exp(-2*u0*h0))*UD;%explanation of equation (16)and (13),similar to equation (11)
            %where the negative exponential term: -uM(i)*zR in equation
            %(6) have added
        end
    end
    
%preparation for output
    CMM=zeros(M,11);
    CNN=zeros(N,11);
    C0MM=[A0M,B0M,C0M,D0M,P0M,Q0M,u0,v0,gama0,bc0,w];
    C0NN=[A0N,B0N,C0N,D0N,P0N,Q0N,u0,v0,gama0,bc0,w];
    for m=1:M
        CMM(m,1:11)=[AM(m),BM(m),CM(m),DM(m),PM(m),QM(m),uM(m),vM(m),gamaM(m),bcM(m),w];
    end
    for n=1:N
        CNN(n,1:11)=[AN(n),BN(n),CN(n),DN(n),PN(n),QN(n),uN(n),vN(n),gamaN(n),bcN(n),w];
    end
end
end

function [G]=tanhG(a)
%digits(50);
expa=(exp(-2*a));     
G=((1-expa)/(1+expa));
end

function [M,bcM,zM,uM,vM,gamaM,TM,YM,RM,XM]=make_M(L,w,zT,modelM,v0,gama0)
J=sqrt(-1);
mu=4*pi*1e-7;
M=size(modelM,1);
modelM(:,3)=modelM(:,3)-zT; %calculate the z-coordinate difference between the measurement point and the ith interface(explained after eqaution 9).
bcM=modelM(:,1);
hM=modelM(:,2);
zM=modelM(:,3);
uM=zeros(M,1);
vM=zeros(M,1);
gamaM=zeros(M,1);
TM=zeros(M,1);
YM=zeros(M,1);
for i=1:M
    uM(i)=sqrt(L^2+J*w*mu*bcM(i)); %equation (6)
    vM(i)=(1/uM(i));               %equation (9)
    gamaM(i)=(J*w*mu*bcM(i)/uM(i));%explanation of equation (13)
end
TM(M)=vM(M);     %equation (5a)
YM(M)=gamaM(M);  %explanation of equation (13)
if M>1
    for i=M-1:-1:1
        TM(i)=vM(i)*(TM(i+1)+vM(i)*tanhG(uM(i)*hM(i)))/(vM(i)+TM(i+1)*tanhG(uM(i)*hM(i)));          %equation (8)
        YM(i)=gamaM(i)*(YM(i+1)+gamaM(i)*tanhG(uM(i)*hM(i)))/(gamaM(i)+YM(i+1)*tanhG(uM(i)*hM(i))); %equation (13)
    end
end
RM=((TM(1)+v0)/(TM(1)-v0));        %explanation of equation (8b)
XM=((YM(1)+gama0)/(YM(1)-gama0));  %explanation of equation (4c)
end

function [N,bcN,zN,uN,vN,gamaN,TN,YN,RN,XN]=make_N(L,w,zT,modelN,v0,gama0)
%the gamaN,YN, XN are used served for geting the the coefficents of vector
%potentials for vertical electric dipole source.

%the vN,TN, RN are used served for geting the the coefficents of vector
%potentials for horizontal electric dipole source
J=sqrt(-1);
mu=4*pi*1e-7;
N=size(modelN,1);
modelN(:,3)=modelN(:,3)-zT;%calculate the z-coordinate difference between the measurement point and the ith interface(explained after eqaution 9).
bcN=modelN(:,1);
hN=modelN(:,2);
zN=modelN(:,3);
uN=zeros(N,1);
vN=zeros(N,1);
gamaN=zeros(N,1);
TN=zeros(N,1);
YN=zeros(N,1);

for j=1:N
    uN(j)=sqrt(L^2+J*w*mu*bcN(j)); %equation (6)
    vN(j)=(1/uN(j));               %equation (9)
    gamaN(j)=(J*w*mu*bcN(j)/uN(j));%explanation of equation (13)
end
TN(N)=-vN(N);    %equation (5a) 
YN(N)=-gamaN(N); %explanation of equation (13)
if N>1
    for j=N-1:-1:1
        TN(j)=vN(j)*(TN(j+1)-vN(j)*tanhG(uN(j)*hN(j)))/(vN(j)- TN(j+1)*tanhG(uN(j)*hN(j)));        %equation (8) 
        YN(j)=gamaN(j)*(YN(j+1)-gamaN(j)*tanhG(uN(j)*hN(j)))/(gamaN(j)-YN(j+1)*tanhG(uN(j)*hN(j)));%equation (13)
    end
end
RN=((TN(1)+v0)/(TN(1)-v0));        %explanation of equation (8b) 
XN=((YN(1)+gama0)/(YN(1)-gama0));  %explanation of equation (4c)
end


