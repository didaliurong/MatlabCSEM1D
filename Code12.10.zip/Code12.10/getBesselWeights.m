%------------------------------------------------------------------%
% Copyright (c) 2012 by the Society of Exploration Geophysicists.  %
% For more information, go to http://software.seg.org/2012/0003 .  %
% You must read and accept usage terms at:                         %
% http://software.seg.org/disclaimer.txt before use.               %
%------------------------------------------------------------------%

function [xInt Bx BJ0 BJ1] = getBesselWeights(nIntervalsMax,nQuad,sZeroType)                      
%
% Returns the quadrature intervals and Bessel function weights used for the 
% QWE method.
%
% Usage:
%
% [xInt Bx BJ0 BJ1] = getBesselWeights(nIntervalsMax,nQuad,sZeroType)     
%
% Inputs:
%
% nIntervalsMax - maximum number of quadrature intervals
% nQuad         - quadrature order
% sZeroType     - breakpoint type: zeros of 'J0','J1' or the simple 'nPi' spacing   
%
% Outputs:
%
% xInt   - breakpoints for dividing up the global integral
% Bx     - global vector of all quadrature points between all breakpoints 
% BJ0    - the corresponding J0 weights,  w*J0(Bx) 
% BJ1    - the corresponding J1 weights,  w*J1(Bx) 
%
% Written by:
%
% Kerry Key 
% Scripps Institution of Oceanography
%
% History:
%
% May 2011  - implemented
%
% External functions required:
% -getGaussQuadWeights
%
% Subfunctions contained here:
% -getBesselZeros
%--------------------------------------------------------------------------

    Int_0 = 1d-20; % Lower limit of integrand, a small but non-zero value

    %
    % Get the Gauss quadrature weights:
    %
    [x w] = getGaussQuadWeights(nQuad);
    
    %
    % Get the zeros:
    %
    switch (lower(sZeroType))
        case('j0')
            xz = getBesselZeros(0,nIntervalsMax)';
            
        case('j1')
            xz = getBesselZeros(1,nIntervalsMax)';
             
        case('npi')
            xz = (1:nIntervalsMax)*pi; 
    end
    
    xInt = [Int_0 xz ];
    
    %
    % Assemble the output arrays, coded for speed not clarity:
    %
    dx  = diff(xInt)/2;  % spacing
    Bx  = dx(ones(length(x),1),:).*(x(:,ones(length(xInt)-1,1))+1);
    Bx  = Bx + xInt(ones(length(x),1),1:end-1);
    Bx  = reshape(Bx,numel(Bx),1); 
    BJ0 = besselj(0,Bx).*repmat(w,length(xInt)-1,1);
    BJ1 = besselj(1,Bx).*repmat(w,length(xInt)-1,1);

end
%--------------------------------------------------------------------------
% Subfunctions:
%--------------------------------------------------------------------------

%--------------------------------------------------------------------------
function x = getBesselZeros(nu,N)
%
% Computes N zeros of the Bessel function of the first kind of order nu
% using the Newton-Raphson method, which is fast enough for our purposes.
%
% Uses the asymptotic zeros as a starting guess and computes all values in
% parallel, which seems to be the fastest way to go with Matlab.
%
% Written by:
%
% Kerry Key
% Scripps Institution of Oceanography
%
%-------------------------------------------------------------------------- 
    
    % Initial guess using asymptotic zeros:
    x = (1:N)'*pi+nu*pi/2-pi/4;
 
    % Newton-Raphson iterations    
    for i = 1:10   % 10 is more than enough, usually stops in 5
        
        % Evaluate:
        x0 = besselj(nu,x);
        x1 = besselj(nu+1,x); 
        g = nu ./ x;
       
        % The step length:
        h = -x0 ./ (g.*x0-x1);
        
        % Take the step:
        x = x + h;           
        
        % Check for convergence:
        if all(abs(h) < 8*eps(x))
            break
        end
    end  

end
 

 
 
