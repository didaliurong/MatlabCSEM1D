%Calculate the  electric field and magnetic field distribution at bisector x=y for x-directed electric dipole source

%input:
%bc,h,z                -layered model description
%TX,T0,f,              -parameters of dipole source  
%xxB,yyB,zzB           -position of the measurement points at bisector x=y 

%output:
%XEx,XEy,XEz     -the electric field at measurement points 
%XHx,XHy,XHz     -the magnetic field at measurement points 

%code structure:
%call: slect_model   -to rearrange the layered model parameters according to the position of the dipole source
%call: E_XED         -to return the electric fields by x-directed electric dipole
%call: H_XED         -to return the magnetic fields by x-directed electric dipole


tic;
%input*************model description  *******************
bc=[1d-12,   3.3      1       0.01     0.1      0.05    0.01];%conductivity of each layers(from topmost to bottom layer);
h=[1d60,     500     1000     500     500      1000     1d60];%thickness of each layer
z=[      0        500     1500    2000     2500     3500    ];%interface
%design the Tx-Rx
TX=[0,0,1750];                                                %position of the transmitter
T0=4;                                                         % the transmitter is the 4th layer
[Tmodel0,TmodelM,TmodelN]=select_model(T0,bc,h,z);% Rearrange the order of layers
f=1;                               %frequency of the transmitter
%positions of the receivers (here xxB is the range of bisector x=y )
xxB=[-8200:400:8200]./1.414;
yyB=xxB;
zzB=0.1:200:4000.1;
P=length(xxB)*length(zzB);
PS=zeros(P,3);
for i=1:length(xxB)
    for k=1:length(zzB)
        m=(i-1)*length(zzB)+k;
        PS(m,1)=xxB(i);
        PS(m,2)=yyB(i);
        PS(m,3)=zzB(k);
    end
end% end of the input***********

[ XEx,XEy,XEz ]=E_XED(PS,TX,Tmodel0,TmodelM,TmodelN,f);%return the electric fields by x-directed electric dipole
XEx=sqrt(XEx.^2+XEy.^2); %transform the x- and y- directed fields into bisector x=y plan

%output the result
filename1=strcat(num2str(f),'Hz','example XED caused electric vector in 7 layer model.txt');
fid1=fopen(filename1,'wt');

for i=1:P
    fprintf(fid1,'%12.5g\t',PS(i,1));%the x-coordinate of the measurement point
    fprintf(fid1,'%12.5g\t',PS(i,3)); %the z-coordinate of the measurement point
    fprintf(fid1,'%12.5g\t',real(XEx(i)));%the real part of x-directed electric field
    fprintf(fid1,'%12.5g\t',imag(XEx(i)));%the image part of x-directed electric field
    fprintf(fid1,'%12.5g\t',real(XEz(i)));%the real part of z-directed electric field
    fprintf(fid1,'%12.5g\n',imag(XEz(i)));%the image part of z-directed electric field
end

[ XHx,XHy,XHz ]=H_XED(PS,TX,Tmodel0,TmodelM,TmodelN,f);%return the magnetic fields by x-directed electric dipole
XHx=sqrt(XHx.^2+XHy.^2); %transform the x- and y- directed fields into bisector x=y plan

%output the result
filename2=strcat(num2str(f),'Hz','example XED caused magnetic vector in 7 layer model.txt.txt');
fid2=fopen(filename2,'wt');

for i=1:P
    fprintf(fid2,'%12.5g\t',PS(i,1));%the x-coordinate of the measurement point
    fprintf(fid2,'%12.5g\t',PS(i,3)); %the z-coordinate of the measurement point 
    fprintf(fid2,'%12.5g\t',real(XHx(i)));%the real part of x-directed magnetic field
    fprintf(fid2,'%12.5g\t',imag(XHx(i)));%the image part of x-directed magnetic field
    fprintf(fid2,'%12.5g\t',real(XHz(i)));%the real part of z-directed magnetic field
    fprintf(fid2,'%12.5g\n',imag(XHz(i)));%%the image part of z-directed magnetic field
end
toc;

