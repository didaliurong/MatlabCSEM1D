xxB=(-8200:400:8200)/1000;
zzB=(0.1:200:4000.1)/1000;
J=sqrt(-1);
%
EB1HZ=importdata('1Hzexample ZMD caused electric vector in 7 layer model.txt');

XEx=EB1HZ(:,3)+J*EB1HZ(:,4);
XEz=EB1HZ(:,5)+J*EB1HZ(:,6);

ExB_inphase=zeros(length(zzB),length(xxB));
ExB_outphase=zeros(length(zzB),length(xxB));
EzB_inphase=zeros(length(zzB),length(xxB));
EzB_outphase=zeros(length(zzB),length(xxB));
ESB_inphase=zeros(length(zzB),length(xxB));
ESB_outphase=zeros(length(zzB),length(xxB));
for i=1:length(xxB)
    for j=1:length(zzB)
        k=(i-1)*length(zzB)+j;
        
        ExB_inphase(j,i)=real(XEx(k));
        ExB_outphase(j,i)=imag(XEx(k));
        EzB_inphase(j,i)=real(XEz(k));
        EzB_outphase(j,i)=imag(XEz(k));
        ESB_inphase(j,i)=log10((sqrt(real(XEx(k))^2+real(XEz(k))^2)));
        ESB_outphase(j,i)=log10((sqrt(imag(XEx(k))^2+imag(XEz(k))^2)));
    end
end
%
HB1HZ=importdata('1Hzexample ZMD caused magnetic vector in 7 layer model.txt');

XHx=HB1HZ(:,3)+J*HB1HZ(:,4);
XHz=HB1HZ(:,5)+J*HB1HZ(:,6);

HxB_inphase=zeros(length(zzB),length(xxB));
HxB_outphase=zeros(length(zzB),length(xxB));
HzB_inphase=zeros(length(zzB),length(xxB));
HzB_outphase=zeros(length(zzB),length(xxB));
HSB_inphase=zeros(length(zzB),length(xxB));
HSB_outphase=zeros(length(zzB),length(xxB));

for i=1:length(xxB)
    for j=1:length(zzB)
        k=(i-1)*length(zzB)+j;
        
        HxB_inphase(j,i)=real(XHx(k));
        HxB_outphase(j,i)=imag(XHx(k));
        HzB_inphase(j,i)=real(XHz(k));
        HzB_outphase(j,i)=imag(XHz(k));
        HSB_inphase(j,i)=log10((sqrt(real(XHx(k))^2+real(XHz(k))^2)));
        HSB_outphase(j,i)=log10((sqrt(imag(XHx(k))^2+imag(XHz(k))^2)));
    end
end
%%
figure(8);
subplot(2,2,1)
contourf(xxB,zzB,ESB_inphase,500,'LineColor','none');
colormap(jet);
%colorbar
caxis([-18,-12])
k=caxis;
axis ([-8,8,0,4]);
set(gca,'xticklabel',[])
set(gca,'ydir','reverse')
set(gca,'FontName','Times New Roman','FontSize',28)
%xlabel('Range(m)','FontName','Times New Roman','FontSize',20)
ylabel('Z(km)','FontName','Times New Roman','FontSize',28)
title('Inphase E-vectors','FontSize',28)

hold on 
h=quiver (xxB,zzB,ExB_inphase./sqrt(ExB_inphase.^2+EzB_inphase.^2),EzB_inphase./sqrt(ExB_inphase.^2+EzB_inphase.^2),'k');
set(h,'MaxHeadSize',0.2,'AutoScaleFactor',0.5)
plot([8,-8],[0.5,0.5],'w-','Linewidth',2)
plot([8,-8],[1.5,1.5],'w-','Linewidth',2)
plot([8,-8],[2,2],'w-','Linewidth',2)
plot([8,-8],[2.5,2.5],'w-','Linewidth',2)
plot([8,-8],[3.5,3.5],'w-','Linewidth',2)
hold off

subplot(2,2,3)
contourf(xxB,zzB,ESB_outphase,500,'LineColor','none'); 
caxis(k)
colorbar
h=colorbar;
set(get(h,'title'),'string','log10(V/m)');
set(h,'position',[0.5,0.21,0.02,0.61]);

axis ([-8,8,0,4]);
set(gca,'FontName','Times New Roman','FontSize',28)
xlabel('Range(km)','FontName','Times New Roman','FontSize',28)
set(gca,'XTick',-8:2:8);
set(gca,'ydir','reverse')
ylabel('Z(km)','FontName','Times New Roman','FontSize',28)
title('Quadrature E-vectors','FontSize',28)
hold on 
h=quiver (xxB,zzB,ExB_outphase./sqrt(ExB_outphase.^2+EzB_outphase.^2),EzB_outphase./sqrt(ExB_outphase.^2+EzB_outphase.^2),'k');
set(h,'MaxHeadSize',0.2,'AutoScaleFactor',0.5)
plot([8,-8],[0.5,0.5],'w-','Linewidth',2)
plot([8,-8],[1.5,1.5],'w-','Linewidth',2)
plot([8,-8],[2,2],'w-','Linewidth',2)
plot([8,-8],[2.5,2.5],'w-','Linewidth',2)
plot([8,-8],[3.5,3.5],'w-','Linewidth',2)
hold off

subplot(2,2,2)
contourf(xxB,zzB,HSB_inphase,500,'LineColor','none');
colormap(jet);
%colorbar
caxis([-16,-8])
k1=caxis;
axis ([-8,8,0,4]);
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
set(gca,'ydir','reverse')
set(gca,'FontName','Times New Roman','FontSize',28)
%xlabel('X(m)','FontName','Times New Roman','FontSize',20)
%ylabel('Z(m)','FontName','Times New Roman','FontSize',28)
title('Inphase H-vectors','FontSize',28)
hold on 
h=quiver (xxB,zzB,HxB_inphase./sqrt(HxB_inphase.^2+HzB_inphase.^2),HzB_inphase./sqrt(HxB_inphase.^2+HzB_inphase.^2),'k');
set(h,'MaxHeadSize',0.2,'AutoScaleFactor',0.5)
plot([8,-8],[0.5,0.5],'w-','Linewidth',2)
plot([8,-8],[1.5,1.5],'w-','Linewidth',2)
plot([8,-8],[2,2],'w-','Linewidth',2)
plot([8,-8],[2.5,2.5],'w-','Linewidth',2)
plot([8,-8],[3.5,3.5],'w-','Linewidth',2)
hold off

subplot(2,2,4)
contourf(xxB,zzB,HSB_outphase,500,'LineColor','none'); 
caxis(k1)
colorbar
h=colorbar;
set(get(h,'title'),'string','log10(A/m)');
set(h,'position',[0.94,0.21,0.02,0.61]);

axis ([-8,8,0,4]);
set(gca,'yticklabel',[])
set(gca,'FontName','Times New Roman','FontSize',28)
xlabel('Range(km)','FontName','Times New Roman','FontSize',28)
set(gca,'XTick',-8:2:8);
set(gca,'ydir','reverse')
%ylabel('Z(m)','FontName','Times New Roman','FontSize',20)
title('Quadrature H-vectors','FontSize',28)
% title('log10(V/m)','FontSize',28)
hold on 
h=quiver (xxB,zzB,HxB_outphase./sqrt(HxB_outphase.^2+HzB_outphase.^2),HzB_outphase./sqrt(HxB_outphase.^2+HzB_outphase.^2),'k');
set(h,'MaxHeadSize',0.2,'AutoScaleFactor',0.5)
plot([8,-8],[0.5,0.5],'w-','Linewidth',2)
plot([8,-8],[1.5,1.5],'w-','Linewidth',2)
plot([8,-8],[2,2],'w-','Linewidth',2)
plot([8,-8],[2.5,2.5],'w-','Linewidth',2)
plot([8,-8],[3.5,3.5],'w-','Linewidth',2)
hold off

