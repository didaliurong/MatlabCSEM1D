xxP=-200:16:200;
yyP=-200:16:200;
J=sqrt(-1);

EP1HZ=importdata('10000Hzairborne ZMD caused eleltric vectors plane view.txt');

XEx=EP1HZ(:,3)+J*EP1HZ(:,4);
XEy=EP1HZ(:,5)+J*EP1HZ(:,6);

ExP_inphase=zeros(length(yyP),length(xxP));
ExP_outphase=zeros(length(yyP),length(xxP));
EyP_inphase=zeros(length(yyP),length(xxP));
EyP_outphase=zeros(length(yyP),length(xxP));
ESP_inphase=zeros(length(yyP),length(xxP));
ESP_outphase=zeros(length(yyP),length(xxP));

for i=1:length(xxP)
for j=1:length(yyP)    
    k=(i-1)*length(yyP)+j;   
    ExP_inphase(j,i)=real(XEx(k));  
    ExP_outphase(j,i)=imag(XEx(k));
    EyP_inphase(j,i)=real(XEy(k));  
    EyP_outphase(j,i)=imag(XEy(k));
    ESP_inphase(j,i)=log10(0.01*(sqrt(real(XEx(k))^2+real(XEy(k))^2)));  
    ESP_outphase(j,i)=log10(0.01*(sqrt(imag(XEx(k))^2+imag(XEy(k))^2)));       
end
end

%
xxD=-202:4:202;
zzD=0:2:100;
J=sqrt(-1);

ED1HZ=importdata('10000Hzairborne ZMD caused eleltric vectors section view.txt');

XEx=ED1HZ(:,3)+J*ED1HZ(:,4);
XEy=ED1HZ(:,5)+J*ED1HZ(:,6);

ExD_inphase=zeros(length(zzD),length(xxD));
ExD_outphase=zeros(length(zzD),length(xxD));
EyD_inphase=zeros(length(zzD),length(xxD));
EyD_outphase=zeros(length(zzD),length(xxD));
ESD_inphase=zeros(length(zzD),length(xxD));
ESD_outphase=zeros(length(zzD),length(xxD));

for i=1:length(xxD)
for j=1:length(zzD)    
    k=(i-1)*length(zzD)+j; 
    
    ExD_inphase(j,i)=real(XEx(k));  
    ExD_outphase(j,i)=imag(XEx(k));
    EyD_inphase(j,i)=real(XEy(k));  
    EyD_outphase(j,i)=imag(XEy(k));
    ESD_inphase(j,i)=log10(0.01*(sqrt(real(XEx(k))^2+real(XEy(k))^2)));  
    ESD_outphase(j,i)=log10(0.01*(sqrt(imag(XEx(k))^2+imag(XEy(k))^2)));       
end
end

%%
figure(13);
subplot(2,2,1)
contourf(xxP,yyP,ESP_inphase,500,'LineColor','none');
colormap(jet);
caxis([-10,-7]);
k=caxis;
axis ([-200,200,-200,200]);
set(gca,'xticklabel',[])
set(gca,'ydir','reverse')
set(gca,'FontName','Times New Roman','FontSize',28)
% xlabel('X(m)','FontName','Times New Roman','FontSize',20)
ylabel('Y(m)','FontName','Times New Roman','FontSize',28)
title('Inphase currents','FontSize',28)
hold on 
h=quiver (xxP,yyP,ExP_inphase./sqrt(ExP_inphase.^2+EyP_inphase.^2),EyP_inphase./sqrt(ExP_inphase.^2+EyP_inphase.^2),'k');
set(h,'MaxHeadSize',0.2,'AutoScaleFactor',0.5)
hold off

subplot(2,2,2)
contourf(xxP,yyP,ESP_outphase,500,'LineColor','none'); 
caxis(k)
%colorbar
axis ([-200,200,-200,200]);
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
set(gca,'ydir','reverse')
set(gca,'FontName','Times New Roman','FontSize',28)
title('Quadrature currents','FontSize',28)
% xlabel('X(m)','FontName','Times New Roman','FontSize',20)
% ylabel('Y(m)','FontName','Times New Roman','FontSize',20)
hold on 
h=quiver (xxP,yyP,ExP_outphase./sqrt(ExP_outphase.^2+EyP_outphase.^2),EyP_outphase./sqrt(ExP_outphase.^2+EyP_outphase.^2),'k');
set(h,'MaxHeadSize',0.2,'AutoScaleFactor',0.5)
hold off

subplot(2,2,3)
contourf(xxD,zzD,ESD_inphase,500,'LineColor','none');
caxis(k)
axis ([-200,200,0,100]);
set(gca,'FontName','Times New Roman','FontSize',28)
set(gca,'ydir','reverse')
 xlabel('X(m)','FontName','Times New Roman','FontSize',28)
 ylabel('Z(m)','FontName','Times New Roman','FontSize',28)
% hold on 
% quiver (xx,zz,Ex_inphase./sqrt(Ex_inphase.^2+Ey_inphase.^2),Ey_inphase./sqrt(Ex_inphase.^2+Ey_inphase.^2),'k');
% hold off

subplot(2,2,4)
contourf(xxD,zzD,ESD_outphase,500,'LineColor','none'); 
caxis(k)
colorbar
h=colorbar;
set(get(h,'title'),'string','log10(A)');
set(h,'position',[0.93,0.21,0.02,0.61]);
axis ([-200,200,0,100]);
set(gca,'yticklabel',[])
set(gca,'ydir','reverse')
set(gca,'FontName','Times New Roman','FontSize',28)
xlabel('X(m)','FontName','Times New Roman','FontSize',28)

% ylabel('Z(m)','FontName','Times New Roman','FontSize',20)
% hold on 
% quiver (xx,zz,Ex_outphase./sqrt(Ex_outphase.^2+Ey_outphase.^2),Ey_outphase./sqrt(Ex_outphase.^2+Ey_outphase.^2),'k');
% hold off

