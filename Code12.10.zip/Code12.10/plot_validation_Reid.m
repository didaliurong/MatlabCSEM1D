
 %%
f=(1:0.2:5);
J=sqrt(-1);
%
ZMD=importdata('Reid validation��ZMD��curves.txt');
ZMD_analysis=-ZMD(:,2)-J*ZMD(:,3);
ZMD_numerical=-ZMD(:,4)-J*ZMD(:,5);
%
XMD=importdata('Reid validation��XMD��curves.txt');
XMD_analysis=-XMD(:,2)-J*XMD(:,3);
XMD_numerical=-XMD(:,4)-J*XMD(:,5);

%
figure(3);
subplot(2,1,1)
plot(f,log10(real(ZMD_analysis)),'r-',...
     f,log10(imag(ZMD_analysis)),'b-',...
     f,log10(real(ZMD_numerical)),'r*',...
     f,log10(imag(ZMD_numerical)),'b*','Linewidth',2)
     %f,log10(imag(ZMD_numerical)),'b.','Linewidth',2)
%xlabel('Range (m)','FontName','Times New Roman','FontSize',20)
ylabel('log10[Amplitude(A/m)]','FontName','Times New Roman','FontSize',28)
axis ([1,5,-12,-6])
set(gca,'xticklabel',[])
set(gca,'FontName','Times New Roman','FontSize',28)
%set(gca,'ytick',10.^[-30:2:0])
h1=legend('Inphase(VMD-analytical)','Quadrature(VMD-analytical)','Inphase(VMD-numerical)','Quadrature(VMD-numerical)');
set(h1,'FontName','Times New Roman','FontSize',28)
%title('Secondary magnetic field(Hs)','FontName','Times New Roman','FontSize',28)

subplot(2,1,2)
plot(f,log10(real(XMD_analysis)),'r-',...
     f,log10(imag(XMD_analysis)),'b-',...
     f,log10(real(XMD_numerical)),'r*',...
     f,log10(imag(XMD_numerical)),'b*','Linewidth',2)
xlabel('log10[frequency(Hz)]','FontName','Times New Roman','FontSize',28)
ylabel('log10[Amplitude(A/m)]','FontName','Times New Roman','FontSize',28)
axis ([1,5,-12,-6])
set(gca,'FontName','Times New Roman','FontSize',28)
%set(gca,'ytick',10.^[-30:2:0])
 h1=legend('Inphase(HMD-analytical)','Quadrature(HMD-analytical)','Inphase(HMD-numerical)','Quadrature(HMD-numerical)');
% set(h1,'FontName','Times New Roman','FontSize',28)


