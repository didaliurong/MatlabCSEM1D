%z_directed magnetic field by z_directed unit magnetic dipole in whole space
function WZ = ZH_whole( PS,TX,f,bc)
%the expression is according to Ward, S. H. and Hohmann, G. W., 1987.

%input:
%PS -the position of the measurement point 
%TX -the position of the dipole source
%f  -the frequency of the dipole source
%bc -the conductivity of the whole space

%output:
%WZ  -the z_directed magnetic field

%code structure:
%called by: Reid_validationZMD.m

WZ=zeros(size(PS,1),1);
J=sqrt(-1);
k=sqrt(J*2*pi*f*4*pi*1d-7*bc);

for i=1:size(PS,1)
    dx=PS(i,1)-TX(1);
    dy=PS(i,2)-TX(2);
    dz=PS(i,3)-TX(3);
    R=sqrt(dx^2+dy^2+dz^2);
    
    WZ(i,1)=exp(-J*k*R)/(4*pi*R^3)*(k^2*R^2-J*k*R-1);
end
end

