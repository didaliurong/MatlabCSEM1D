%return the magnetic fields caused by z-directed unit electric dipole
function [ AHx,AHy,AHz ] = H_ZED(PS,PV,model0,modelM,modelN,f)
%input:
%PS -positions of the measrement points 
%PV -positions of the dipole sources 
%model0  -parameters of the layer with the dipole source 
%modelM  -parameters of layers beneath the dipole source 
%modelN  -parameters of layers above the dipole source 
%f       -the frequency of the dipole source

%output:
%AHx    -the x-directed magnetic field
%AHy    -the y-directed magnetic field
%AHz    -the z-directed magnetic field

%code structure:
%called by: example_ZED_Vector.m
%call: H_qweZED  -to return the integration of Bessel function by qwe

%parameters of qwe*********
relTol = 1d-12;        %relative tolerance of QWE
absTol = 1d-24;        %absolute tolerance of QWE
mQuad  = 101;           %quadrature order
nIntervalsMax = 20;    %number of intervals
[xIntervals Bx BJ0 BJ1] = getBesselWeights(nIntervalsMax,mQuad,'j1');

AHx=zeros(size(PS,1),size(PV,1));
AHy=zeros(size(PS,1),size(PV,1));
AHz=zeros(size(PS,1),size(PV,1));
w=2*pi*f;

% parpool('local',4);
% p=gcp('nocreat');
% parfor iRx = 1:size(PS,1)
for iRx = 1:size(PS,1)
    mytempt=zeros(3,size(PV,1));
    for iTx = 1:size(PV,1)
        dx=PS(iRx,1)-PV(iTx,1);
        dy=PS(iRx,2)-PV(iTx,2);
        R=sqrt(dx^2+dy^2);
        zR=PS(iRx,3);
        zT=PV(iTx,3);
        
        intervals = xIntervals/R;
        lambda    = Bx/R;
        
        TVX = H_qweZED(relTol,absTol,nIntervalsMax,intervals,mQuad,lambda,BJ0,BJ1,R,dx,dy,zR,zT,model0,modelM,modelN,w);
        
        mytempt(1,iTx) = TVX(1).extrap(TVX(1).n);
        mytempt(2,iTx) = TVX(2).extrap(TVX(2).n);
        mytempt(3,iTx) = TVX(3).extrap(TVX(3).n);
    end
    AHx(iRx,:)=mytempt(1,:);
    AHy(iRx,:)=mytempt(2,:);
    AHz(iRx,:)=mytempt(3,:);
end
%delete(p);
end


