
function T = H_qweZMD(rtol,atol,nIntervalsMax,intervals,nQuad,lambda,BJ0,BJ1,R,dx,dy,zR,zT,model0,modelM,modelN,w)
%return the magnetic field by z-directed magnetic dipole source by qwe
%adapted from Key 2012    

%input:
%rtol,atol      -error tolerance of qwe 
%nIntervalsMax  -maximum number of intervals of qwe
%intervals -breakpoints for dividing up the global integral
%nQuad     -number of qudrarature points in each interval
%lambda    -wave number for evaluation of kernel functions of EM fields
%BJ0,BJ1   -corresponding J0 and J1 weights
%R         -the horizontal distance of dipole source and measurement point
%dx,dy     -the x-coordinate and y-coordinate different between the dipole source and measurement point 
%zR,zT     -z coordinate of the dipole source and measurement point
%model0,modelM,modelN  -rearranged layered parameters according to the position of the dipole source
%w         -the angular frequency of the dipole source

%code structure:
%called by:H_ZMD.m
%call: CAL_MDabcdpq         -to return coefficients of vector potential by magnetic dipole at each layer 
%call: getCSEM1DKernelsVX   -to return explicit expressions of EM field derived from the vector potential
                                   

    nDelay = 1;  % must be >= 1, but 1 is usually sufficient.
    prev = 0;
    for i = 1:nDelay          
        Bindex = (i-1)*nQuad +(1:nQuad);
        EyK  = zeros(length(Bindex),6);
        for j = 1:length(Bindex)
           [C0M,C0N,CM,CN] = CAL_MDabcdpq(lambda(Bindex(j)),model0,modelM,modelN,zR,zT,w);           
           EyK(j,1:6) = getCSEM1DKernelsVX(lambda(Bindex(j)),R,modelM,modelN,dx,dy,zR,zT,C0M,C0N,CM,CN);                    
        end
        bma=(intervals(i+1)-intervals(i))/2;
        EyKernels=[0,0,0];
        EyKernels(1)=bma*(EyK(:,1).'*BJ0(Bindex)) +  bma*(EyK(:,2).'*BJ1(Bindex));
        EyKernels(2)=bma*(EyK(:,3).'*BJ0(Bindex)) +  bma*(EyK(:,4).'*BJ1(Bindex)); 
        EyKernels(3)=bma*(EyK(:,5).'*BJ0(Bindex)) +  bma*(EyK(:,6).'*BJ1(Bindex));  
        prev    = prev + EyKernels; % Call to func returns quadrature sum
    end

% Initialize the T structure for the extrapolation results:
    nKernels = length(prev);  % func from nDelay loop above returns nKernels results
    nTerms   = nIntervalsMax-nDelay-1;  % maximum number of terms in extrapolation  
    rmin     = realmin;
        
    for i = 1:nKernels  % Preallocating arrays at maximum size for speed:
        T(i).S      = zeros(nTerms,1); % working array used for the recursion coefficients for the Epsilon algorithm
        T(i).extrap = zeros(nTerms,1); % extrapolated result for each order of the expansion
        T(i).relErr = zeros(nTerms,1); % relative error for each order 
        T(i).absErr = zeros(nTerms,1); % absolute error for each order    
        converged   = false(nKernels,1); 
    end
    
% The extrapolation transformation loop****************    
    for i = nDelay+1:nTerms
        % Step 1: Compute Guass quadrature of this interval:     
        Bindex = (i-1)*nQuad +(1:nQuad);
        EyK  = zeros(length(Bindex),6);
        for j = 1:length(Bindex)           
           [C0M,C0N,CM,CN] = CAL_MDabcdpq(lambda(Bindex(j)),model0,modelM,modelN,zR,zT,w);        
           EyK(j,1:6) = getCSEM1DKernelsVX(lambda(Bindex(j)),R,modelM,modelN,dx,dy,zR,zT,C0M,C0N,CM,CN);                    
        end
        bma=(intervals(i+1)-intervals(i))/2;
        f=[0,0,0];
        f(1)=bma*(EyK(:,1).'*BJ0(Bindex)) +  bma*(EyK(:,2).'*BJ1(Bindex)); 
        f(2)=bma*(EyK(:,3).'*BJ0(Bindex)) +  bma*(EyK(:,4).'*BJ1(Bindex));
        f(3)=bma*(EyK(:,5).'*BJ0(Bindex)) +  bma*(EyK(:,6).'*BJ1(Bindex));

        % Step 2: Compute Shanks transformation for each kernel function:
        for j = 1:nKernels            
            if  converged(j)  % skip this kernel since its done 
                continue;
            end

            % Insert components into the T structure:
            n           = i-nDelay;
            T(j).n      = n;               % order of the expansion  
            T(j).S(n+1) = T(j).S(n)+f(j);  % working array for transformation

            % Compute the Shanks transform using the Epsilon algorithm:
            % Structured after Weniger (1989, p26)
            aux2 = 0;
            for k = n+1:-1:2
                aux1 = aux2;
                aux2 = T(j).S(k-1);
                ddff = T(j).S(k) - aux2;
                if abs(ddff) < rmin||ddff==0  
                    T(j).S(k-1) = 0;
                else
                    T(j).S(k-1) = aux1 + 1/ddff;
                end
            end
            
            % The extrapolated result plus the prev integration term:
            T(j).extrap(n) = T(j).S(mod(n,2)+1)+prev(j); 
            
            % Step 3: Analyze for convergence:
            if n > 1
                T(j).absErr(n) = abs( T(j).extrap(n) - T(j).extrap(n-1));
                T(j).relErr(n) = T(j).absErr(n) / abs(T(j).extrap(n)) ;  
                if T(j).extrap(n)==0  
                   converged(j)=1;    
                else                  
                converged(j)   = T(j).relErr(n) < rtol + atol/abs(T(j).extrap(n));
                end
            end           
        end % loop over nKernels
        
        if all(converged) 
            break; 
        end        
    end % end extrapolation loop*******************
    
    % Clean up the T structure arrays:
    for j = 1:nKernels  
        n = T(j).n;
        T(j).extrap = T(j).extrap(1:n);  
        T(j).relErr = T(j).relErr(1:n); 
        T(j).absErr = T(j).absErr(1:n);  
    end
end 


function EyKernels = getCSEM1DKernelsVX(L,R,modelM,modelN,dx,dy,zR,zT,C0M,C0N,CM,CN)
%return the explicit expressions of EM field derived from the vector potential by J0, J1 order
%find the receiver's layer order*****************
if length(CM)==1%for source in the bottom layer
    if zR<=modelN(1,3)
        pL = max(find(modelN(:,3) > zR)); 
        A=CN(pL,5);B=CN(pL,6);C=CN(pL,3);D=CN(pL,4);P=CN(pL,5);Q=CN(pL,6);u=CN(pL,7);bc=CN(pL,10);w=CN(pL,11);
    else if zR<=zT
            A=C0N(5);B=C0N(6);C=C0N(3);D=C0N(4);P=C0N(5);Q=C0N(6);u=C0N(7);bc=C0N(10);w=C0N(11);
        else
            A=C0M(5);B=C0M(6);C=C0M(3);D=C0M(4);P=C0M(5);Q=C0M(6);u=C0M(7);bc=C0M(10);w=C0M(11);
        end
    end
end

if length(CN)==1%for source in the topmost layer
    if zR>modelM(1,3)
        pL = max(find(modelM(:,3) <= zR));  
        A=CM(pL,5);B=CM(pL,6);C=CM(pL,3);D=CM(pL,4);P=CM(pL,5);Q=CM(pL,6);u=CM(pL,7);bc=CM(pL,10);w=CM(pL,11);
    else if zR<=zT
            A=C0N(5);B=C0N(6);C=C0N(3);D=C0N(4);P=C0N(5);Q=C0N(6);u=C0N(7);bc=C0N(10);w=C0N(11);
        else
            A=C0M(5);B=C0M(6);C=C0M(3);D=C0M(4);P=C0M(5);Q=C0M(6);u=C0M(7);bc=C0M(10);w=C0M(11);
        end
    end
end

if    length(CN)~=1 &&length(CM)~=1%for source in the middle layer
    if zR<=modelN(1,3)
        pL = max(find(modelN(:,3) > zR)); 
        A=CN(pL,5);B=CN(pL,6);C=CN(pL,3);D=CN(pL,4);P=CN(pL,5);Q=CN(pL,6);u=CN(pL,7);bc=CN(pL,10);w=CN(pL,11);
    else if zR>modelM(1,3)
            pL = max(find(modelM(:,3) <= zR)); 
            A=CM(pL,5);B=CM(pL,6);C=CM(pL,3);D=CM(pL,4);P=CM(pL,5);Q=CM(pL,6);u=CM(pL,7);bc=CM(pL,10);w=CM(pL,11);
        else if zR<=zT
                A=C0N(5);B=C0N(6);C=C0N(3);D=C0N(4);P=C0N(5);Q=C0N(6);u=C0N(7);bc=C0N(10);w=C0N(11);
            else
                A=C0M(5);B=C0M(6);C=C0M(3);D=C0M(4);P=C0M(5);Q=C0M(6);u=C0M(7);bc=C0M(10);w=C0M(11);
            end
        end
    end
end%end find***************


u0=C0M(7);
J=sqrt(-1);
mu=4*pi*1e-7;

%vector potentials 
%A33J0=(1/4*pi)*(L/u0)*(P+Q);
A33J1=0;

%differential of vector potential 
V13J0=0;
V13J1=-dx/(4*pi*R)*(L^2*u/u0)*(P-Q);
V23J0=0;
V23J1=-dy/(4*pi*R)*(L^2*u/u0)*(P-Q);
%V33J0=1/(4*pi)*(L*u^2/u0)*(P+Q);
V33J1=0;

%fields derived from potentials 
%x-directed magnetic fields by z-directed magnetic dipole
HZxJ0=V13J0;
HZxJ1=V13J1;
%y-directed magnetic fields by z-directed magnetic dipole
HZyJ0=V23J0;
HZyJ1=V23J1;
%z-directed magnetic fields by z-directed magnetic dipole
HZzJ0=1/(4*pi)*((L^3)/u0*(P+Q)); 
HZzJ1=-J*w*mu*bc*A33J1+V33J1;

EyKernels=[HZxJ0 HZxJ1 HZyJ0 HZyJ1 HZzJ0 HZzJ1];
end
