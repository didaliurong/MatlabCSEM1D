function [C0MM,C0NN,CMM,CNN]=makeMD_M0(L,zR,model0,w,N,bcN,zN,uN,vN,gamaN,ZN,YN,RN,XN)
%return the coefficents of vector potential for magnetic source in the bottom layer
%called by: CAL_MDabcdpq.m 
%the input and output parameters are explained in CAL_MDabcdpq.m

J=sqrt(-1);
mu=4*pi*1e-7;
bc0=model0(1,1);
u0=sqrt(L^2+J*w*mu*bc0);
v0=bc0/u0;
gama0=1/u0;

AN=zeros(N,1);BN=zeros(N,1);
CN=zeros(N,1);DN=zeros(N,1);
PN=zeros(N,1);QN=zeros(N,1);
CMM=0;        CNN=zeros(N,11);


%simplified from A0M,C0M,P0M,B0M,D0M,Q0M in CAL_EDabcdpq.m by setting RM=infinity,XM=infinity,zM(1)=h0=positive infinity
A0M=0;
C0M=0;
P0M=0;

B0M=RN*exp(2*u0*zN(1)-u0*zR)+exp(-u0*zR);
D0M=XN*exp(2*u0*zN(1)-u0*zR)-exp(-u0*zR);
Q0M=XN*exp(2*u0*zN(1)-u0*zR)+exp(-u0*zR);

%simplified from A0N,C0N,P0N,B0N,D0N,Q0N in CAL_EDabcdpq.m by setting RM=infinity,XM=infinity,zM(1)=h0=positive infinity
A0N=exp(u0*zR);
C0N=exp(u0*zR);
P0N=exp(u0*zR);

B0N=RN*exp(2*u0*zN(1)-u0*zR);
D0N=XN*exp(2*u0*zN(1)-u0*zR);
Q0N=XN*exp(2*u0*zN(1)-u0*zR);

%*******CNN
UA=(ZN(1)-vN(1))/(ZN(1)-v0);
UB=(ZN(1)+vN(1))/(ZN(1)+v0);
UC=(YN(1)-gamaN(1))/(YN(1)-gama0);
UD=(YN(1)+gamaN(1))/(YN(1)+gama0);

%simplified from AN,CN,PN,BN,DN,QN in CAL_EDabcdpq.m by setting RM=infinity,XM=infinity,zM(1)=h0=positive infinity
XP=uN(1)*zR+zN(1)*(u0-uN(1));                                             
AN(1)=exp(XP)*UA*(bc0/bcN(1)); 
CN(1)=exp(XP)*UC;
PN(1)=exp(XP)*UC;

XP=-uN(1)*zR+zN(1)*(uN(1)-u0);
BN(1)=RN*exp(XP+2*u0*zN(1))*UB*(bc0/bcN(1)); 
DN(1)=XN*exp(XP+2*u0*zN(1))*UD;
QN(1)=XN*exp(XP+2*u0*zN(1))*UD;
if N>1
    AXP=zN(1)*(u0-uN(1));
    BXP=zN(1)*(uN(1)-u0);
    for j=2:N
       
        UA=UA*(ZN(j)-vN(j))/(ZN(j)-vN(j-1));
        AXP=AXP+zN(j)*(uN(j-1)-uN(j));
        AN(j)=exp(AXP+uN(j)*zR)*UA*(bc0/bcN(j));
       
        UB=UB*(ZN(j)+vN(j))/(ZN(j)+vN(j-1));
        BXP=BXP+zN(j)*(uN(j)-uN(j-1));
        BN(j)=RN*exp(BXP+2*u0*zN(1)-uN(j)*zR)*UB*(bc0/bcN(j));
       
        UC=UC*(YN(j)-gamaN(j))/(YN(j)-gamaN(j-1));
        CN(j)=exp(AXP+uN(j)*zR)*UC;
        PN(j)=exp(AXP+uN(j)*zR)*UC;
     
        UD=UD*(YN(j)+gamaN(j))/(YN(j)+gamaN(j-1));
        DN(j)=XN*exp(BXP+2*u0*zN(1)-uN(j)*zR)*UD;
        QN(j)=XN*exp(BXP+2*u0*zN(1)-uN(j)*zR)*UD;
    end
end

%preparation for output
C0MM=[A0M,B0M,C0M,D0M,P0M,Q0M,u0,v0,gama0,bc0,w];
C0NN=[A0N,B0N,C0N,D0N,P0N,Q0N,u0,v0,gama0,bc0,w];
for n=1:N
    CNN(n,1:11)=[AN(n),BN(n),CN(n),DN(n),PN(n),QN(n),uN(n),vN(n),gamaN(n),bcN(n),w];
end
end


