%Calculate the  electric current distribution at section view 

%input:
%bc,h,z                   -layered model description
%TX,T0,f,                 -parameters of dipole source  
%xxB,yyB,zzB              -position of the measurement points for 1D background model
%xx,yy,zz                 -position of the measurement points for 1D reservoir model


%output:
%XEx,XEy,XEz         -the electric field at measurement points by x-directed electric dipole source

%code structure:
%call: select_model  -to rearrange the layered model parameters according to the position of the dipole source
%call: E_XED         -to return the electric fields by x-directed electric dipole

tic;
%background model
%input*************model description  *******************
bc=[1d-12,   3.3                1];%conducutivity from topmost layer to deepest layer
h=[1d60,    1000             1d60];%thickness from topmost layer to deepest layer
z=[      0       1000            ];%interface 
%design the Tx-Rx
TX=[0,0,950];                      %position of the transmitter
T0=2;                              % the source layer is the 2th layer 
[Tmodel0,TmodelM,TmodelN]=select_model(T0,bc,h,z);% Rearrange the order of layers
f=1;                               %frequency of the transmitter
%positions of the measurement points
xxB=-8200:400:8200;
yyB=0;
zzB=0.1:200:4000.1;
P=length(xxB)*length(yyB)*length(zzB);
PS=zeros(P,3);
for i=1:length(xxB)
  for j=1:length(yyB)
      for k=1:length(zzB)
        m=(i-1)*length(yyB)*length(zzB)+(j-1)*length(zzB)+k;
        PS(m,1)=xxB(i);
        PS(m,2)=yyB(j);
        PS(m,3)=zzB(k);
      end
  end
end%end input*************

 [ XEx,XEy,XEz ]=E_XED(PS,TX,Tmodel0,TmodelM,TmodelN,f);%return the electric fields by x-directed electric source 

%output results        
filename1=strcat(num2str(f),'Hz','marine 1D electric vector in background model.txt');
fid1=fopen(filename1,'wt');

for i=1:P
    fprintf(fid1,'%12.5g\t',PS(i,1));%the x-coordinate of the measurement point
    fprintf(fid1,'%12.5g\t',PS(i,3)); %the z-coordinate of the measurement point
    fprintf(fid1,'%12.5g\t',real(XEx(i)));%the real part of x-directed electric field
    fprintf(fid1,'%12.5g\t',imag(XEx(i)));%the image part of x-directed electric field
    fprintf(fid1,'%12.5g\t',real(XEz(i)));%the real part of z-directed electric field
    fprintf(fid1,'%12.5g\n',imag(XEz(i)));%the image part of z-directed electric field
end


%%

%%1D reservoir model
%model description
bc=[1d-12,   3.3           1        0.01         1];
h=[1d60,    1000        1000        100       1d60];
z=[      0       1000         2000      2100      ];

%design Tx-Rx
TX=[0,0,950];
T0=2;
[Tmodel0,TmodelM,TmodelN]=select_model(T0,bc,h,z);
%positions of the measurement points
xx=-8200:400:8200;
yy=0;
zz=0.1:200:4000.1;
P=length(xx)*length(yy)*length(zz);
PS=zeros(P,3);
for i=1:length(xx)
  for j=1:length(yy)
      for k=1:length(zz)
        m=(i-1)*length(yy)*length(zz)+(j-1)*length(zz)+k;
        PS(m,1)=xx(i);
        PS(m,2)=yy(j);
        PS(m,3)=zz(k);
      end
  end
end

 [ XEx,XEy,XEz ]=E_XED(PS,TX,Tmodel0,TmodelM,TmodelN,f);%return the electric fields by x-directed electric source 

%output results               
filename2=strcat(num2str(f),'Hz','marine 1D electric vector in reservior model.txt');
fid2=fopen(filename2,'wt');
for i=1:P
    fprintf(fid2,'%12.5g\t',PS(i,1));%the x-coordinate of the measurement point
    fprintf(fid2,'%12.5g\t',PS(i,3)); %the z-coordinate of the measurement point
    fprintf(fid2,'%12.5g\t',real(XEx(i)));%the real part of x-directed electric field
    fprintf(fid2,'%12.5g\t',imag(XEx(i)));%the image part of x-directed electric field
    fprintf(fid2,'%12.5g\t',real(XEz(i)));%the real part of z-directed electric field
    fprintf(fid2,'%12.5g\n',imag(XEz(i)));%the image part of z-directed electric field
end
toc;


