%return the x_directed magnetic field by unit vector electric dipole in whole space 
function HX = wholeHX(PS,PV,f,bc)
%the expression is according to Ward, S. H. and Hohmann, G. W., 1987.

%input:
%PS -the position of the measurement point 
%PV -the position of the dipole source
%f  -the frequency of the dipole source
%bc -the conductivity of the whole space

%output:
%HX  -the x_directed magnetic field

%code structure:
%called by: Reid_validationXMD.m

HX=zeros(size(PS,1),3*size(PV,1));
J=sqrt(-1);
k=sqrt(J*2*pi*f*4*pi*1d-7*bc);

for iRx = 1:size(PS,1)   
    for iTx = 1:size(PV,1)
        dx=PS(iRx,1)-PV(iTx,1);
        dy=PS(iRx,2)-PV(iTx,2);          
        dz=PS(iRx,3)-PV(iTx,3);
        
        R=sqrt(dx^2+dy^2+dz^2);
        
        HX(iRx,3*(iTx-1)+1)=0;
        
        HX(iRx,3*(iTx-1)+2)=((J*k*R+1)*exp(-J*k*R)/(4*pi*R^3))*dz;
        
        HX(iRx,3*(iTx-1)+3)=-((J*k*R+1)*exp(-J*k*R)/(4*pi*R^3))*dy;    
    end
end
end
