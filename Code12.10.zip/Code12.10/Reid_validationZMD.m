%Calculate the analytical and numerical solutions of the secondary field by the thin sheet embodied in whole space electric field 
%the source is an z-directed magnetic dipole

%input:
%bc,h,z                 -layered model description
%TX,T0,ff,              -parameters of dipole source  
%xxP,yyP,zzP            -position of the elements dicretized from the thin sheet
%RC                     -positions of the measurement points for both analyticaland numerical solutions

%output:
%XEx,XEy,XEz       -the electric field at the center of each elements by z-directed magnetic dipole source
%AHZ               -the magnetic field at RC by unite vector electric dipole in each element
%PZHx11,PZHy,PZHz  -the analytical magnetic field by z-directed magnetic dipole on three layered model
%PZHz0             -the analytical magnetic field by z-directed magnetic dipole on whole space model

%code structure:
%call: slect_model  -to rearrange the layered model parameters according to the position of the dipole source

%calculate the numerical solution:
%call: E_ZMD        -to return the electric fields in each elements by z-directed magnetic dipole
%call: wholeHZ      -to calculate the numerical solution of secondary field at RC by the currents in each element 

%calculate the analytical solution:
%call: H_ZMD        -to calculate the analytical field at RC by z-directed magnetic dipole on three layered model 
%ZH_whole           -to calculate the analytical field at RC by z-directed magnetic dipole on whole space model 



%model description 
bc=[1d-12,          0.1         1d-12];%conductivity of each layers(from top to deepest);
h=[1d60,             1          1d60];%thickness of each layer
z=[           0            1        ];%interface
%design the Tx-Rx
TX=[0,0,-30];                                                %position of the transmitter
T0=1;                                                        % the transmitter is the 1th layer(air layer)
[Tmodel0,TmodelM,TmodelN]=select_model(T0,bc,h,z);% Rearrange the order of layers 
ff=10.^(1:0.2:5);     %frequencies of the transmitter

%positions of the receivers
%center of discrete cells in the thin sheet
xxP=-804:8:804;
yyP=-804:8:804;
zzP=0.5;  
P=length(xxP)*length(yyP)*length(zzP);
PS=zeros(P,3);
for i=1:length(xxP)
  for j=1:length(yyP)
      for k=1:length(zzP)
        m=(i-1)*length(yyP)*length(zzP)+(j-1)*length(zzP)+k;
        PS(m,1)=xxP(i);
        PS(m,2)=yyP(j);
        PS(m,3)=zzP(k);
      end
  end
end

HZanalysis=zeros(length(ff),1);
HZnumerical=zeros(length(ff),1);
SHZ_INPHASE=zeros(length(ff),1);
SHZ_OUTPHASE=zeros(length(ff),1);
for ii=1:length(ff)
     %fields by numerical integration
    f=ff(ii);
    [ XEx,XEy,XEz ]=E_ZMD(PS,TX,Tmodel0,TmodelM,TmodelN,f);%return the electric fields at the center of cells  
    RC=[8,0,-30]; %the position of the receiver for the AEM survey system
    AHZ=wholeHZ(RC,PS,f,bc(1));%return the z_directed magnetic field by unit vector electric dipole in whole space 
    SHZ=0;
    
    for i=1:P
        SHZ=SHZ+AHZ(1,(i-1)*3+1)*XEx(i)+AHZ(1,(i-1)*3+2)*XEy(i)+AHZ(1,(i-1)*3+3)*XEz(i);%integrate the z-directed magnetic fields by vector electric fields
    end
    HZnumerical(ii)=(bc(2)-bc(1))*64*SHZ;% Multiply the momment of dipole
    %fields by analytical 
    [PZHx11,PZHy,PZHz]=H_ZMD(RC,TX,Tmodel0,TmodelM,TmodelN,f);  %return the magnetic fields by z-directed unit magnetic dipole on the 3 layer model analyticallly
    PZHz0=ZH_whole(RC,TX,f,bc(1));   %return the magnetic fields by z-directed unit magnetic dipole on the 2 layer model analyticallly
    PZHz=PZHz-PZHz0;  %get x-directed magnetic fields by the thin sheet analytically    
    HZanalysis(ii)=PZHz;   
end

%output results
filename2=strcat('Reid validation��ZMD��curves.txt');
fid2=fopen(filename2,'wt');

for ii=1:length(ff)
    fprintf(fid2,'%12.5g\t',ff(ii));%frequency of the magnetic dipole source 
    fprintf(fid2,'%12.5g\t',real(HZanalysis(ii)));%real part of x-directed magnetic field, analytical solution
    fprintf(fid2,'%12.5g\t',imag(HZanalysis(ii)));%image part of x-directed magnetic field,analytical solution
    fprintf(fid2,'%12.5g\t',real(HZnumerical(ii)));%real part of x-directed magnetic field,numerical solution
    fprintf(fid2,'%12.5g\n',imag(HZnumerical(ii)));%image part of x-directed magnetic field,numerical solution
end





