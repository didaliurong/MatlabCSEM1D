function EyKernels = validation_H(L,R,dx,dy,CM,u0)
%return the value of kernel function (magnetic field) for each lambda

%input:
%L         -the wave number lambda
%R         -the horizontal distance of dipole source and measurement point
%dx,dy     -the x-coordinate and y-coordinate different between the dipole source and measurement point 
%CM,u0        -the coefficients for the layer with the measurement point

A=CM(1);B=CM(2);C=CM(3);D=CM(4);P=CM(5);Q=CM(6);u=CM(7);bc=CM(10);w=CM(11);
%the coefficents from differential
K1XY=(C+D)+(u/u0)*(B-A);
K0XY=L*(C+D)+(L*u/u0)*(B-A);
K1=-(L^2/u0)*(A+B);
K0=(L*u/u0)*(A-B);
P0XY=dx*dy/(4*pi*R^2);
P1XY=2*dx*dy/(4*pi*R^3);
POX=dx^2/(4*pi*R^2);
P1X=(2*dx^2-R^2)/(4*pi*R^3);
%the x-directed magnetic field by x-directed unit electrc dipole
HXxJ0=-P0XY*K0XY;
HXxJ1=P1XY*K1XY;
%the y-directed magnetic field by x-directed unit electrc dipole
HXyJ0=(1/4*pi)*K0+POX*K0XY;
HXyJ1=-P1X*K1XY;
%the z-directed magnetic field by x-directed unit electrc dipole
HXzJ0=0;
HXzJ1=-(1/(4*pi))*(dy/R)*K1;

EyKernels=[HXxJ0 HXxJ1 HXyJ0 HXyJ1 HXzJ0 HXzJ1];
end
